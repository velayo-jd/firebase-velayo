import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  collection, addDoc, updateDoc, deleteDoc, doc,
  query, orderBy, onSnapshot, serverTimestamp, Timestamp,
} from 'firebase/firestore';
import { db } from '../firebase';
import { Debt, NewDebt } from '../models/debts.model';

@Injectable({ providedIn: 'root' })
export class DebtsService {
  private debtsRef = collection(db, 'notes');

  // READ: a live list that re-emits every time the collection changes.
  listNotes(): Observable<Debt[]> {
    const q = query(this.debtsRef, orderBy('createdAt', 'desc'));
    return new Observable<Debt[]>((subscriber) => {
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const debts = snapshot.docs.map((d) => {
            // 'estimate' gives a local time while the server timestamp is still pending
            const data = d.data({ serverTimestamps: 'estimate' });
            const created = data['createdAt'];
            return {
              id: d.id,
              person: data['person'] ?? '',
              amount: data['amount'] ?? '',
              direction: data['direction'] ?? '',
              paid: data['paid'] ?? false,
              createdAt: created instanceof Timestamp ? created.toDate() : null,
            } as Debt;
          });
          subscriber.next(debts);
        },
        (error) => subscriber.error(error),
      );
      return unsubscribe; // stops listening when the page unsubscribes
    });
  }

  // CREATE
  addDebts(debt: NewDebt) {
    return addDoc(this.debtsRef, {
      person: debt.person.trim(),
      amount: Number(debt.amount),
      direction: debt.direction.trim(),
      paid: false,
      createdAt: serverTimestamp(),
    });
  }

  // UPDATE
  setPaid(id: string, paid: boolean) {
    return updateDoc(doc(db, 'notes', id), { paid });
  }

  // DELETE
  deleteNote(id: string) {
    return deleteDoc(doc(db, 'notes', id));
  }
}