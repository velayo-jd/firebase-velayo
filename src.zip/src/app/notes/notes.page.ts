import { Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, of } from 'rxjs';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonListHeader,
  IonItem, IonLabel, IonInput, IonTextarea, IonButton, IonCheckbox, IonText,
} from '@ionic/angular';
import { DebtsService as DebtsService } from '../services/debts.service';
import { Debt as Debts } from '../models/debts.model';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.page.html',
  styleUrls: ['./notes.page.scss'],
  standalone: true,
  imports: [
    FormsModule, DatePipe,
    IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonListHeader,
    IonItem, IonLabel, IonInput, IonTextarea, IonButton, IonCheckbox, IonText,
  ],
})
export class DebtsPage {
  private debtsService = inject(DebtsService);

  person = '';
  amount: number | null = null;
  direction = '';
  errorMsg = signal('');

  // Live list from Firestore, exposed as a signal for the template.
  debts = toSignal(
    this.debtsService.listNotes().pipe(
      catchError((err: Error) => {
        this.errorMsg.set(err.message);
        return of([] as Debts[]);
      }),
    ),
    { initialValue: [] as Debts[] },
  );

  add() {
    const person = this.person.trim();
    const amount = Number(this.amount);
    if (!person || isNaN(amount) || amount <= 0) return;
    this.debtsService
      .addDebts({person, amount, direction: this.direction })
      .catch((err: Error) => this.errorMsg.set(err.message));
    this.person = '';
    this.amount = null;
    this.direction = '';
  }

  toggle(debt: Debts, paid: boolean) {
    this.debtsService.setPaid(debt.id, paid)
      .catch((err: Error) => this.errorMsg.set(err.message));
  }

  remove(debt: Debts) {
    this.debtsService.deleteNote(debt.id)
      .catch((err: Error) => this.errorMsg.set(err.message));
  }
}