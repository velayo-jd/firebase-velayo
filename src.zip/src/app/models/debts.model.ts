export interface Debt {
  id : string;
  person: string;
  amount: number;
  direction: string;
  paid : boolean;
  createdAt: Date | null;
}

// What the form sends when creating a note.
export type NewDebt = Pick<Debt, 'person' | 'direction' | 'amount'>;