export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC7wQTIbyWBR2QYdx7fubAbkiYn4qeZ1dQ",
    authDomain: "mc2-lab1-velayo.firebaseapp.com",
    projectId: "mc2-lab1-velayo",
    storageBucket: "mc2-lab1-velayo.firebasestorage.app",
    messagingSenderId: "351554807448",
    appId: "1:351554807448:web:0d66a6c01b4911650612ed"
  }
};